=============================================================
  DoQA: DOmain  specific  FAQs  via  conversational QA v1.0 
=============================================================

DoQA is a dataset for accessing Domain Specific FAQs via conversational
QA that contains 1,637 information-seeking dialogues on the cooking
domain (7,329 questions in total). Note that we include in the generic
concept of FAQs also Community Question Answering sites, as well as
corporate information in intranets which is maintained in textual form
similar to FAQs, often referred to as internal "knowledge bases".

These dialogues are created by crowd workers that play the following
two roles: the user who asks questions about a certain cooking topic
posted in Stack Exchange (https://cooking.stackexchange.com/), and the
domain expert who replies to the questions by selecting a short span
of text from the long textual reply in the original post. The expert
can rephrase the selected span, in order to make it look more natural.

DoQA enables the development and evaluation of conversational QA
systems that help users access the knowledge buried in domain specific
FAQs.



Dataset structure
-------------------

The dataset is divided into three JSON files in order to use the first
one for the training process (train), the second one for the tuning
process (dev) and the last one for testing (test).


In DoQA we include a ranking of multiple documents that
can be relevant to answerer a query and hence it may be used
to assess the ability of conversational QA systems to perform
a dialog when the exact passage with the correct answers are
not known.

Additionally, we include a ranking of multiple documents that can be
relevant to answer a question and hence it may be used to assess the
ability of conversational QA systems to perform a dialogue when the
exact passage with the correct answers are not nown. In the
'IR_scenario' folder we added two rank files for both development and
test data, in the form of the 20 most relevant answer passages for
each dialogue (given the first question in the dialogue), following
the next two different strategies:

- question retrieval: where relevant or similar questions are searched
  (and thus, the answer for this relevant question is taken as a
  relevant answer); we indexed the original topics posted in the
  forum.

- answer retrieval: where relevant answers are searched directly among
  existing answers; we indexed the answer passages for each post in
  the forum.

The directories are distributed in the following way:

---doqa_dataset
	---doqa-train-v1.0.json		       		 Train split of the dataset in json format

	---doqa-dev-v1.0.json				 Dev split of the dataset in json format

	---doqa-test-v1.0.json				 Test split of the dataset in json format

---ir_scenario
	---doqa-dev-documents-v1.0.tsv		 Documents and documents ids of the dev split:
						 File format(tsv):
						    document_id		 document

	---doqa-dev-ir-answer-v1.0.tsv		 Top 20 documents for each dialogue given by the IR system in the dev file when the answers are indexed:
						 File format(tsv):
						    dialogue_id	  	 document_id	 rank	score	 

	---doqa-dev-ir-question-v1.0.tsv	 Top 20 documents given for each dialogue by the IR system in the dev file when the questions are indexed:
						 File format(tsv):
						    dialogue_id	  	 document_id	 rank	score

	---doqa-dev-relevants-v1.0.tsv		 File containing the correct documents for each dialogue in the dev split:
						 File format(tsv):
						    dialogue_id	     	 document_id

	---doqa-test-documents-v1.0.tsv		 Documents and documents ids of the test split:
						 File format(tsv):
						    document_id		 document

	---doqa-test-ir-answer-v1.0.tsv		 Top 20 documents for each dialogue given by the IR system in the dev file when the answers are indexed:
						 File format(tsv):
						    dialogue_id	  	 document_id	 rank	score

	---doqa-test-ir-question-v1.0.tsv	 Top 20 documents for each dialogue given by the IR system in the dev file when the questions are indexed:
						 File format(tsv):
						    dialogue_id	  	 document_id	 rank	score

	---doqa-test-relevants-v1.0.tsv 	 File containing the correct documents for each dialogue in the test split:
						 File format(tsv):
						    dialogue_id	     	 document_id


You can find more information about the dataset in this publication:
  J.A. Campos, A. Otegi, A. Soroa, J. Deriu, M. Cieliebak,
  E. Conversational QA for FAQs. In: 3rd Conversational AI: Today's
  Practice and Tomorrow's Potential, NeurIPS 2019 workshop. 2019



Authors
-----------
Jon Ander Campos (1), Arantxa Otegi (1), Aitor Soroa (1), Jan Deriu (2),
Mark Cieliebak (2), Eneko Agirre (1)

Affiliation of the authors: 
 (1) University of the Basque Country (UPV/EHU)
 (2) Zurich University of Applied Sciences (ZHAW)



Licensing
-------------
Copyright (C) by Ixa Taldea, University of the Basque Country UPV/EHU.
This dataset is licensed under the Creative Commons
Attribution-ShareAlike 4.0 International Public License (CC BY-SA 4.0).
To view a copy of this license, visit
https://creativecommons.org/licenses/by-sa/4.0/legalcode.



Acknowledgements
-------------------
If you are using this dataset in your work, please cite this
publication:

  J.A. Campos, A. Otegi, A. Soroa, J. Deriu, M. Cieliebak,
  E. Conversational QA for FAQs. In: 3rd Conversational AI: Today's
  Practice and Tomorrow's Potential, NeurIPS 2019 workshop. 2019



Contact information
-----------------------
Jon Ander Campos jonander.campos@ehu.eus
